import React from 'react';
import './App.css';
import CollgeView from './College-view';

class App extends React.Component{

  render() {
      return (
        <CollgeView />
      )
  }
}

export default App;
